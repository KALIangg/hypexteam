local DiscordLib = loadstring(game:HttpGet "https://raw.githubusercontent.com/bloodball/-back-ups-for-libs/main/discord")()
local HttpService = game:GetService("HttpService")
local plr = game.Players.LocalPlayer

local win = DiscordLib:Window("🥷Hypex Revamp V3 - Sun Piece")
local MainS = win:Server("Sun Piece⚔️", "v2.0")

local MainTab = MainS:Channel("Main")
local SkillsTab = MainS:Channel("Skills / Abillity⚔️")
local AutoFarmTab = MainS:Channel("Missions📜")
local AdminTab = MainS:Channel("Server [FE]🔥")

------------------------------------
-- CONFIGS MAIN DO MENU
------------------------------------

MainTab:Seperator()
MainTab:Label("Creditos: Feito por GomesDev, vulgo Hypex.")

local function sendAnnounce(text, color, duration)
	local announces = game.Players.LocalPlayer.PlayerGui:FindFirstChild("Announces")
	if not announces then return end

	local frame = announces:FindFirstChild("Frame")
	local template = announces:FindFirstChild("TextLabel")

	if not frame or not template then return end

	local msg = template:Clone()
	msg.Parent = frame
	msg.Visible = true
	msg.TextColor3 = color or Color3.fromRGB(255, 255, 255)
	msg.Text = text
	wait(duration or 3)
	msg:Destroy()
end

sendAnnounce("💻 Bem vindo(a) ao painel Hypex Revamp! Seu script premium para <Sun Piece>.", Color3.fromRGB(255, 255, 255), 4)

MainTab:Seperator()

------------------------------------
-- NO COOLDOWN
------------------------------------

SkillsTab:Button("🔥 No Cooldown - Frutas, Espadas, Armas e Bloodlines", function()
    local plr = game.Players.LocalPlayer
    local keys = {"Z", "X", "C", "V"} -- Teclas padrão

    local replicated = game:GetService("ReplicatedStorage")

    local fruitFolder = replicated:FindFirstChild("FruitSkills")
    local swordFolder = replicated:FindFirstChild("SwordSkills")
    local gunFolder = replicated:FindFirstChild("GunSkills")
    local bloodlineFolder = replicated:FindFirstChild("BloodlineSkills")

    -- 🔍 Detecta se o player tem uma ferramenta ativa no backpack ou character
    local function detectToolName(folder)
        for _,v in pairs(plr.Backpack:GetChildren()) do
            if folder:FindFirstChild(v.Name) then return v.Name end
        end
        for _,v in pairs(plr.Character:GetChildren()) do
            if folder:FindFirstChild(v.Name) then return v.Name end
        end
        return nil
    end

    -- 🧠 Aplica o cooldown 0 nas skills do objeto ativo
    local function applyCooldown(folder, toolName)
        if toolName and folder then
            local skillFolder = folder:FindFirstChild(toolName)
            if skillFolder then
                for _,key in pairs(keys) do
                    local skill = skillFolder:FindFirstChild(key)
                    if skill and skill:FindFirstChild("Cooldown") then
                        skill.Cooldown.Value = 0
                    end
                end
            end
        end
    end

    -- 💥 Aplica o cooldown para bloodlines (multi estilos)
    local function applyBloodlineCooldown()
        if not bloodlineFolder then return end

        for _,style in pairs(bloodlineFolder:GetChildren()) do
            for _,v in pairs(plr.Backpack:GetChildren()) do
                local bloodSkills = style:FindFirstChild(v.Name)
                if bloodSkills then
                    for _,key in pairs(keys) do
                        local skill = bloodSkills:FindFirstChild(key)
                        if skill and skill:FindFirstChild("Cooldown") then
                            skill.Cooldown.Value = 0
                        end
                    end
                end
            end

            for _,v in pairs(plr.Character:GetChildren()) do
                local bloodSkills = style:FindFirstChild(v.Name)
                if bloodSkills then
                    for _,key in pairs(keys) do
                        local skill = bloodSkills:FindFirstChild(key)
                        if skill and skill:FindFirstChild("Cooldown") then
                            skill.Cooldown.Value = 0
                        end
                    end
                end
            end
        end
    end

    -- 🎯 Detectar ferramentas equipadas do jogador
    local activeFruit = fruitFolder and detectToolName(fruitFolder)
    local activeSword = swordFolder and detectToolName(swordFolder)
    local activeGun = gunFolder and detectToolName(gunFolder)

    -- 💣 Aplicar cooldown nas armas detectadas
    applyCooldown(fruitFolder, activeFruit)
    applyCooldown(swordFolder, activeSword)
    applyCooldown(gunFolder, activeGun)
    applyBloodlineCooldown()

    -- ✅ Confirmação visual
    DiscordLib:Notification("Notification - Sun Piece", "🔥 No Cooldown aplicado com sucesso em todas skills!", "GG")
end)

SkillsTab:Button("🔥 Puxar Haki da Observação - Habilidades", function()
    local Ken = game:GetService("Players").LocalPlayer.values.Ken
    if not Ken then
        print('Something went wrong. - Error: Ken not found.')
        return
    end

    if Ken then
        print("ESP - Built In (Enabled)")
        Ken.Value = 1
        DiscordLib:Notification("Haki da Observação", "Puxado e spoofado com sucesso.", "GG!")
    end
end)


local players = game:GetService("Players")
local uis = game:GetService("UserInputService")
local espConns, espEnabled = {}, false
local requiredLevel = 400 -- Minimum level required to use E ability
local plr = players.LocalPlayer

SkillsTab:Toggle("🔥 Haki OBS V2", false, function(state)
    espEnabled = state

    for _, conn in ipairs(espConns) do conn:Disconnect() end
    espConns = {}

    local function cleanESP(char)
        for _, v in ipairs(char:GetChildren()) do
            if v:IsA("Highlight") or v:IsA("BillboardGui") then
                if v.Name == "ESPHighlight" or v.Name == "PlayerESPThumb" or v.Name == "XrayHighlight" or v.Name == "XrayThumb" then
                    v:Destroy()
                end
            end
        end
    end

    local function applyESP(char, name)
        cleanESP(char)

        local bb = Instance.new("BillboardGui", char)
        bb.Name = "PlayerESPThumb"
        bb.AlwaysOnTop = true
        bb.Size = UDim2.new(0, 150, 0, 40)
        bb.MaxDistance = math.huge
        bb.Adornee = char:FindFirstChild("Head") or char.PrimaryPart or char

        local nameLbl = Instance.new("TextLabel", bb)
        nameLbl.Size = UDim2.new(1,0,0.33,0)
        nameLbl.Position = UDim2.new(0, 0, 0, 0)
        nameLbl.BackgroundTransparency = 1
        nameLbl.TextScaled = true
        nameLbl.TextStrokeTransparency = 0.5
        nameLbl.Text = name
        nameLbl.TextColor3 = Color3.new(1,1,1)
        nameLbl.TextStrokeColor3 = Color3.new(0,0,0)

        local hpLbl = Instance.new("TextLabel", bb)
        hpLbl.Name = "HP"
        hpLbl.Size = UDim2.new(1,0,0.33,0)
        hpLbl.Position = UDim2.new(0, 0, 0.33, 0)
        hpLbl.BackgroundTransparency = 1
        hpLbl.TextScaled = true
        hpLbl.TextStrokeTransparency = 0.5
        hpLbl.TextColor3 = Color3.fromRGB(0,255,0)
        hpLbl.TextStrokeColor3 = Color3.new(0,0,0)

        local lvlLbl = Instance.new("TextLabel", bb)
        lvlLbl.Name = "Level"
        lvlLbl.Size = UDim2.new(1,0,0.33,0)
        lvlLbl.Position = UDim2.new(0, 0, 0.66, 0)
        lvlLbl.BackgroundTransparency = 1
        lvlLbl.TextScaled = true
        lvlLbl.TextStrokeTransparency = 0.5
        lvlLbl.TextColor3 = Color3.fromRGB(0,170,255)
        lvlLbl.TextStrokeColor3 = Color3.new(0,0,0)

        local esp = Instance.new("Highlight", char)
        esp.Name = "ESPHighlight"
        esp.FillColor = Color3.fromRGB(226,0,0)
        esp.OutlineColor = Color3.fromRGB(255,0,0)
        esp.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop

        local hum = char:FindFirstChildWhichIsA("Humanoid")
        local player = players:GetPlayerFromCharacter(char)

        if hum then
            hpLbl.Text = "HP: "..math.floor(hum.Health)
            table.insert(espConns, hum.HealthChanged:Connect(function()
                if hpLbl.Parent then
                    hpLbl.Text = "HP: "..math.floor(hum.Health)
                end
            end))
        end

        if player then
            local levelVal = player:FindFirstChild("values") and player.values:FindFirstChild("Level")
            if levelVal then
                lvlLbl.Text = "LVL: "..levelVal.Value
                table.insert(espConns, levelVal:GetPropertyChangedSignal("Value"):Connect(function()
                    if lvlLbl.Parent then
                        lvlLbl.Text = "LVL: "..levelVal.Value
                    end
                end))
            else
                lvlLbl.Text = "LVL: ???"
            end
        end
    end

    if espEnabled then
        for _, p in ipairs(players:GetPlayers()) do
            if p.Character then applyESP(p.Character, p.Name) end
            table.insert(espConns, p.CharacterAdded:Connect(function(c)
                task.wait(1)
                if espEnabled then applyESP(c, p.Name) end
            end))
        end

        table.insert(espConns, players.PlayerAdded:Connect(function(p)
            table.insert(espConns, p.CharacterAdded:Connect(function(c)
                task.wait(1)
                if espEnabled then applyESP(c, p.Name) end
            end))
        end))

        -- Press E to refresh ESP manually
        table.insert(espConns, uis.InputBegan:Connect(function(input, gpe)
            if not gpe and input.KeyCode == Enum.KeyCode.E and espEnabled then
                local levelVal = plr:FindFirstChild("Values") and plr.Values:FindFirstChild("Level")
                if levelVal and levelVal.Value >= requiredLevel then
                    for _, p in ipairs(players:GetPlayers()) do
                        if p.Character then applyESP(p.Character, p.Name) end
                    end
                else
                    print("🔒 Level too low to activate Observation Haki V2!")
                end
            end
        end))

    else
        for _, p in ipairs(players:GetPlayers()) do
            if p.Character then cleanESP(p.Character) end
        end
    end
end)




------------------------------------
-- CRASH SERVER FE (DYNAMIC UPDATE)
------------------------------------
local plr = game.Players.LocalPlayer
local replicated = game:GetService("ReplicatedStorage")
local crashing = false
local crashConn

local selectedWeapon = nil
local selectedSkill = nil
local currentSkillObject = nil
local skillDropdownRef = nil -- 👈 Referência ao dropdown dinâmico

-- Unir frutas + espadas
local allWeapons = {}
for _,v in pairs(replicated:FindFirstChild("FruitSkills"):GetChildren()) do
	table.insert(allWeapons, v.Name)
end
for _,v in pairs(replicated:FindFirstChild("SwordSkills"):GetChildren()) do
	table.insert(allWeapons, v.Name)
end

AdminTab:Seperator()
AdminTab:Label("💣 Crash Server FE - Legacy Mode (Skill Manual)")

-- Dropdown Arma
AdminTab:Dropdown("Selecionar Arma:", allWeapons, function(wpn)
	selectedWeapon = wpn
	selectedSkill = nil
	currentSkillObject = nil

	-- Detectar origem
	local folder = replicated.FruitSkills:FindFirstChild(wpn) or replicated.SwordSkills:FindFirstChild(wpn)
	if folder then
		local skillNames = {}
		for _, skill in pairs(folder:GetChildren()) do
			if skill:IsA("RemoteEvent") then
				table.insert(skillNames, skill.Name)
			end
		end

		-- 🧹 Apagar dropdown anterior se existir
		if skillDropdownRef then
			skillDropdownRef:Destroy()
			skillDropdownRef = nil
		end

		-- 🧠 Criar novo dropdown dinâmico e guardar referência
		skillDropdownRef = AdminTab:Dropdown("Selecionar Skill:", skillNames, function(skill)
			selectedSkill = skill
			currentSkillObject = folder:FindFirstChild(skill)
		end)
	end
end)

-- Iniciar Crash FE
AdminTab:Button("🔥 Iniciar Crash FE (Normal)", function()
	if crashing then
		DiscordLib:Notification("Crash FE", "Já está ativo!", "Oops")
		return
	end
	if not currentSkillObject then
		DiscordLib:Notification("Crash FE", "Selecione arma e skill primeiro!", "Oops")
		return
	end

	crashing = true
	DiscordLib:Notification("Crash FE", "🔥 Crash FE iniciado com skill "..selectedSkill.."!", "GG")

	crashConn = game:GetService("RunService").RenderStepped:Connect(function()
		currentSkillObject:FireServer(plr.Name)
		task.wait(0.05)
	end)
end)

-- Parar Crash FE
AdminTab:Button("🛑 Parar Crash FE", function()
	if crashing then
		crashing = false
		if crashConn then crashConn:Disconnect() end
		DiscordLib:Notification("Crash FE", "Parado com sucesso!", "GG")
	end
end)










------------------------------------
-- INVENTORY MANAGER SUPREME V3
------------------------------------

local InventoryTab = MainS:Channel("Inventory Manager 🧰")

InventoryTab:Seperator()
InventoryTab:Label("Auto Load Perfil 🗂️")

local autoLoadProfile = [[
{}
]]

if plr:FindFirstChild("values") then
    local loaded = HttpService:JSONDecode(autoLoadProfile)
    for name, value in pairs(loaded) do
        local v = plr.values:FindFirstChild(name)
        if v then
            v.Value = value
        end
    end
    sendAnnounce("💾 Save: todos seus itens foram carregados!", Color3.fromRGB(0, 255, 0), 4)
end

------------------------------------
-- ESPADAS 🔪
------------------------------------
InventoryTab:Seperator()
InventoryTab:Label("Espadas 🔪")

for i = 1, 20 do
    InventoryTab:Button("Ativar Sword"..i, function()
        local v = plr.values:FindFirstChild("Sword"..i)
        if v then
            v.Value = 1
            local swordClone = game:GetService("ReplicatedStorage").Weapons:FindFirstChild("Sword"..i)
            if swordClone then
                swordClone:Clone().Parent = plr.Backpack
            end
        end
        DiscordLib:Notification("Notification - Sun Piece", "Sword"..i.." ativada e clonada!", "GG")
    end)
end

InventoryTab:Button("Ativar Todas Swords", function()
	for _,v in pairs(plr.values:GetChildren()) do
		if v.Name:match("^Sword%d+") then
			v.Value = 1
		end
	end
	DiscordLib:Notification("Notification - Sun Piece", "Todas Swords ativadas!", "GG")
end)

------------------------------------
-- ARMAS 🔫
------------------------------------
InventoryTab:Seperator()
InventoryTab:Label("Armas 🔫")

for i = 1, 6 do
    InventoryTab:Button("Ativar Gun"..i, function()
        local v = plr.values:FindFirstChild("Gun"..i)
        if v then
            v.Value = 1
        end
        DiscordLib:Notification("Notification - Sun Piece", "Gun"..i.." ativada!", "GG")
    end)
end

InventoryTab:Button("Ativar Todas Guns", function()
	for _,v in pairs(plr.values:GetChildren()) do
		if v.Name:match("^Gun%d+") then
			v.Value = 1
		end
	end
	DiscordLib:Notification("Notification - Sun Piece", "Todas Guns ativadas!", "GG")
end)

------------------------------------
-- EMOTES 💃
------------------------------------
InventoryTab:Seperator()
InventoryTab:Label("Emotes 💃")

for i = 1, 15 do
    InventoryTab:Button("Ativar Emote"..i, function()
        local v = plr.values:FindFirstChild("Emote"..i)
        if v then
            v.Value = 1
        end
        DiscordLib:Notification("Notification - Sun Piece", "Emote"..i.." ativado!", "GG")
    end)
end

InventoryTab:Button("Ativar Todos Emotes", function()
	for _,v in pairs(plr.values:GetChildren()) do
		if v.Name:match("^Emote%d+") then
			v.Value = 1
		end
	end
	DiscordLib:Notification("Notification - Sun Piece", "Todos Emotes ativados!", "GG")
end)

------------------------------------
-- ACESSÓRIOS 🎭
------------------------------------
InventoryTab:Seperator()
InventoryTab:Label("Acessórios 🎭")

for i = 1, 10 do
    InventoryTab:Button("Ativar Acc"..i, function()
        local v = plr.values:FindFirstChild("Acc"..i)
        if v then
            v.Value = 1
            local accClone = game:GetService("ReplicatedStorage").Accessories:FindFirstChild("Acc"..i)
            if accClone then
                accClone:Clone().Parent = plr.Backpack
            end
        end
        DiscordLib:Notification("Notification - Sun Piece", "Acc"..i.." ativado e clonado!", "GG")
    end)
end

InventoryTab:Button("Ativar Todos Accs", function()
    for i = 1, 10 do
        local v = plr.values:FindFirstChild("Acc"..i)
        if v then
            v.Value = 1
            local accClone = game:GetService("ReplicatedStorage").Accessories:FindFirstChild("Acc"..i)
            if accClone then
                accClone:Clone().Parent = plr.Backpack
            end
        end
    end
    DiscordLib:Notification("Notification - Sun Piece", "Todos Accs ativados e clonados!", "GG")
end)

------------------------------------
-- GERENCIAMENTO PERFIL 🗂️
------------------------------------
InventoryTab:Seperator()
InventoryTab:Label("Gerenciamento Perfil 🗂️")

InventoryTab:Button("Salvar Perfil (Copy JSON)", function()
    local valuesFolder = plr:FindFirstChild("values")
    if valuesFolder then
        local data = {}
        for _,v in pairs(valuesFolder:GetChildren()) do
            data[v.Name] = v.Value
        end
        setclipboard(HttpService:JSONEncode(data))
        DiscordLib:Notification("Notification - Sun Piece", "Perfil Copiado!", "GG")
    end
end)

InventoryTab:Button("Carregar Perfil (Paste JSON)", function()
    local valuesFolder = plr:FindFirstChild("values")
    if valuesFolder then
        local input = DiscordLib:Prompt("Colar JSON do Perfil", "Insira seu JSON aqui:")
        if input then
            local loaded = HttpService:JSONDecode(input)
            for name, value in pairs(loaded) do
                local v = valuesFolder:FindFirstChild(name)
                if v then
                    v.Value = value
                end
            end
            DiscordLib:Notification("Notification - Sun Piece", "Perfil Carregado!", "GG")
        end
    end
end)

InventoryTab:Button("Visualizar Todos Values", function()
    local valuesFolder = plr:FindFirstChild("values")
    if valuesFolder then
        print("====== VALORES ATUAIS ======")
        for _,v in pairs(valuesFolder:GetChildren()) do
            print(v.Name.." = "..v.Value)
        end
        DiscordLib:Notification("Notification - Sun Piece", "Check console para lista!", "GG")
    end
end)




-------- fruits tab -------------

local farming = false
local CurrentLevel = game.Players.LocalPlayer.values.Level.Value
local selectedType = nil
local selectedEnemy = nil -- Mantido para compatibilidade futura
local selectedSkill = "Click"
local currentTarget = nil
local autofarmConnection

local plr = game.Players.LocalPlayer
local rs = game:GetService("ReplicatedStorage")
local ts = game:GetService("TweenService")
local runService = game:GetService("RunService")
local workspace = game:GetService("Workspace")

local function tweenToTarget(targetModel)
	local destinationPosition
	if targetModel:IsA("Model") then
		destinationPosition = targetModel.PrimaryPart and targetModel.PrimaryPart.Position
		if not destinationPosition and targetModel:FindFirstChild("HumanoidRootPart") then
			destinationPosition = targetModel.HumanoidRootPart.Position
		end
	elseif targetModel:IsA("BasePart") then
		destinationPosition = targetModel.Position
	end

	if not destinationPosition then
		warn("Destino inválido para tween!")
		return
	end

	local root = plr.Character and plr.Character:FindFirstChild("HumanoidRootPart")
	if not root then return end

	local floatOffset = Vector3.new(0, 20, 0)
	local targetCFrame = CFrame.new(destinationPosition + floatOffset)

	local distance = (destinationPosition - root.Position).Magnitude
	local tweenInfo = TweenInfo.new(distance / 300, Enum.EasingStyle.Linear, Enum.EasingDirection.Out)

	local tween = ts:Create(root, tweenInfo, {CFrame = targetCFrame})
	tween:Play()
	tween.Completed:Wait()
end

local function aimAt(target)
	local root = plr.Character and plr.Character:FindFirstChild("HumanoidRootPart")
	local targetRoot = target:FindFirstChild("HumanoidRootPart")
	if root and targetRoot then
		root.CFrame = CFrame.new(root.Position, Vector3.new(targetRoot.Position.X, root.Position.Y, targetRoot.Position.Z))
	end
end

local function expandHitbox(model)
	local hrp = model:FindFirstChild("HumanoidRootPart")
	if hrp then
		hrp.Size = Vector3.new(60, 60, 60)
		hrp.CanCollide = false
		hrp.Transparency = (selectedSkill == "Click") and 0.5 or 1
	end
end

local function resetHitbox(model)
	local hrp = model:FindFirstChild("HumanoidRootPart")
	if hrp then
		hrp.Size = Vector3.new(2, 2, 1)
		hrp.Transparency = 1
	end
end

local function findValidTool(toolType)
	local sourceFolder = (toolType == "Fruits") and rs:FindFirstChild("Fruits") or rs:FindFirstChild("Swords")
	if not sourceFolder then return nil end

	local validNames = {}
	for _, v in pairs(sourceFolder:GetChildren()) do
		table.insert(validNames, v.Name)
	end

	for _, tool in pairs(plr.Backpack:GetChildren()) do
		if table.find(validNames, tool.Name) then
			return tool
		end
	end

	for _, tool in pairs(plr.Character:GetChildren()) do
		if table.find(validNames, tool.Name) then
			return tool
		end
	end

	return nil
end

local function getNextTarget()
	local list = {}
	for _, obj in pairs(workspace:GetDescendants()) do
		if obj:IsA("Model") and obj:FindFirstChild("Humanoid") and obj:FindFirstChild("HumanoidRootPart")
			and obj.Humanoid.Health > 0 then

			local npcLevel = tonumber(obj.Name:match("%[Lvl%s?(%d+)%]"))
			if npcLevel and npcLevel <= CurrentLevel and npcLevel + 10 >= CurrentLevel then
				table.insert(list, obj)
			end
		end
	end

	table.sort(list, function(a, b)
		local hrp = plr.Character and plr.Character:FindFirstChild("HumanoidRootPart")
		if not hrp then return false end
		return (a.HumanoidRootPart.Position - hrp.Position).Magnitude < (b.HumanoidRootPart.Position - hrp.Position).Magnitude
	end)

	return list[1]
end

local function startFarm()
	farming = true
	currentTarget = nil

	autofarmConnection = runService.RenderStepped:Connect(function()
		if not selectedType then return end

		local tool = findValidTool(selectedType)
		if not tool then return end
		if tool.Parent ~= plr.Character then
			tool.Parent = plr.Character
		end

		if not currentTarget or not currentTarget:FindFirstChild("Humanoid") or currentTarget.Humanoid.Health <= 0 then
			currentTarget = getNextTarget()
		end

		if not currentTarget then return end

		expandHitbox(currentTarget)

		local hrp = currentTarget:FindFirstChild("HumanoidRootPart")
		if not hrp then return end

		aimAt(currentTarget)
		tweenToTarget(currentTarget)

		if selectedSkill == "Click" then
			tool:Activate()
		else
			local folder = (selectedType == "Fruits") and rs.FruitSkills or rs.SwordSkills
			local skillFolder = folder:FindFirstChild(tool.Name)
			if skillFolder then
				local skill = skillFolder:FindFirstChild(selectedSkill)
				if skill then
					skill:FireServer()
				end
			end
		end

		task.wait(2)
	end)
end

local function stopFarm()
	farming = false
	if autofarmConnection then
		autofarmConnection:Disconnect()
	end
	if currentTarget then
		resetHitbox(currentTarget)
	end
	currentTarget = nil
end

local allEnemies = {}
local function scanAllEnemies()
	allEnemies = {}
	for _, obj in pairs(workspace:GetDescendants()) do
		if obj:IsA("Model") and obj:FindFirstChild("Humanoid") and obj.Name:match("%[Lvl%s?%d+%]") then
			table.insert(allEnemies, obj.Name)
		end
	end
end
scanAllEnemies()

AutoFarmTab:Seperator()
AutoFarmTab:Label("⚔️ Tipo de Ferramenta")
AutoFarmTab:Dropdown("Tipo de Ataque", {"Fruits", "Swords"}, function(opt)
	selectedType = opt
end)

AutoFarmTab:Label("🌀 Skill para usar")
AutoFarmTab:Dropdown("Skill", {"Click", "Z", "X", "C", "V"}, function(option)
	selectedSkill = option
end)

AutoFarmTab:Seperator()
AutoFarmTab:Toggle("Ativar AutoFarm", false, function(state)
	if state then
		startFarm()
	else
		stopFarm()
	end
end)




--------------------------------
-------    NPCS MENUS    -------
--------------------------------


local NPCGuiTab = MainS:Channel("📜 NPC Menus")

local plr = game.Players.LocalPlayer
local npcsFolder = plr:WaitForChild("PlayerGui"):WaitForChild("Npc's")

NPCGuiTab:Seperator()
NPCGuiTab:Label("🍇 Fruta / Perms")

NPCGuiTab:Toggle("FruitDealer 🍇", false, function(state)
	local gui = npcsFolder:FindFirstChild("FruitDealer")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("EatFruit 🍏", false, function(state)
	local gui = npcsFolder:FindFirstChild("EatFruit")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("UsePerm 🎁", false, function(state)
	local gui = npcsFolder:FindFirstChild("UsePerm")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Seperator()
NPCGuiTab:Label("🗡️ Espadas / Acessórios")

NPCGuiTab:Toggle("SwordDealer 🗡️", false, function(state)
	local gui = npcsFolder:FindFirstChild("SwordDealer")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("Accessories 🎭", false, function(state)
	local gui = npcsFolder:FindFirstChild("Accessories")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("AccDealer1 🎭", false, function(state)
	local gui = npcsFolder:FindFirstChild("AccDealer1")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("EmmaDealer 🗡️", false, function(state)
	local gui = npcsFolder:FindFirstChild("EmmaDealer")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("ArmorDealer1 🛡️", false, function(state)
	local gui = npcsFolder:FindFirstChild("ArmorDealer1")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("ArmorDealer2 🛡️", false, function(state)
	local gui = npcsFolder:FindFirstChild("ArmorDealer2")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("ArmorDealer3 🛡️", false, function(state)
	local gui = npcsFolder:FindFirstChild("ArmorDealer3")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Seperator()
NPCGuiTab:Label("🌌 Raças / Awakenings")

NPCGuiTab:Toggle("RaceAwakener 🌌", false, function(state)
	local gui = npcsFolder:FindFirstChild("RaceAwakener")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("RaceAwakenerV3 💠", false, function(state)
	local gui = npcsFolder:FindFirstChild("RaceAwakenerV3")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("DragonRaceDealer 🐲", false, function(state)
	local gui = npcsFolder:FindFirstChild("DragonRaceDealer")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("LeviathanRaceDealer 🌊", false, function(state)
	local gui = npcsFolder:FindFirstChild("LeviathanRaceDealer")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("SpinRace 🎡", false, function(state)
	local gui = npcsFolder:FindFirstChild("SpinRace")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Seperator()
NPCGuiTab:Label("⚔️ Haki / Estilos")

NPCGuiTab:Toggle("KenTeacher 👁️", false, function(state)
	local gui = npcsFolder:FindFirstChild("KenTeacher")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("DrachHaki 🐉", false, function(state)
	local gui = npcsFolder:FindFirstChild("DrachHaki")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("HakiColor 🌈", false, function(state)
	local gui = npcsFolder:FindFirstChild("HakiColor")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("MonkeyStyleDealer 🐒", false, function(state)
	local gui = npcsFolder:FindFirstChild("MonkeyStyleDealer")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("DarkStepDealer 👣", false, function(state)
	local gui = npcsFolder:FindFirstChild("DarkStepDealer")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("DragonTalonDealer 🔥", false, function(state)
	local gui = npcsFolder:FindFirstChild("DragonTalonDealer")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("ScientistCook 🍳", false, function(state)
	local gui = npcsFolder:FindFirstChild("ScientistCook")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Seperator()
NPCGuiTab:Label("🌀 Portais / Áreas / Exploração")

NPCGuiTab:Toggle("GetBackToFirst 🌍", false, function(state)
	local gui = npcsFolder:FindFirstChild("GetBackToFirst")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("GetBackToSecond 🌊", false, function(state)
	local gui = npcsFolder:FindFirstChild("GetBackToSecond")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("SecondSeaExpert 🌊", false, function(state)
	local gui = npcsFolder:FindFirstChild("SecondSeaExpert")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("ThirdSeaExpert 🌋", false, function(state)
	local gui = npcsFolder:FindFirstChild("ThirdSeaExpert")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("MirrorWorldDealer 🪞", false, function(state)
	local gui = npcsFolder:FindFirstChild("MirrorWorldDealer")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("IceDoor1 ❄️", false, function(state)
	local gui = npcsFolder:FindFirstChild("IceDoor1")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("Shenron 🐉", false, function(state)
	local gui = npcsFolder:FindFirstChild("Shenron")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("OkarunNPC 👻", false, function(state)
	local gui = npcsFolder:FindFirstChild("OkarunNPC")
	if gui then gui.Enabled = state end
end)

NPCGuiTab:Toggle("Snowman ☃️", false, function(state)
	local gui = npcsFolder:FindFirstChild("Snowman")
	if gui then gui.Enabled = state end
end)




----------------------------
------CMD-X SYSTEM--------
----------------------------
local TextChatService = game:GetService("TextChatService")
local plr = game.Players.LocalPlayer

local CmdTab = MainS:Channel("💻 CMD SYSTEM V2.5 [CORRIGIDO]")

-- COMANDOS
local crashing = false
local crashThread = nil

local function crash()
	local fruit = nil
	local rs = game:GetService("ReplicatedStorage")

	-- Detecta fruta equipada
	for _,v in pairs(game.Players.LocalPlayer.Backpack:GetChildren()) do
		for _,f in pairs(rs.Fruits:GetChildren()) do
			if v.Name == f.Name then
				fruit = f.Name
			end
		end
	end

	if not fruit then
		sendAnnounce("❌ Nenhuma fruta encontrada no Backpack!", Color3.fromRGB(255, 0, 0), 3)
		return
	end

	local skill = rs.FruitSkills:FindFirstChild(fruit)
	local skillz = skill and (fruit == "Dragon" and skill:FindFirstChild("C") or skill:FindFirstChild("Z"))

	if not skillz then
		sendAnnounce("❌ Skill Z/C não encontrada para "..fruit, Color3.fromRGB(255, 0, 0), 3)
		return
	end

	if crashing then
		sendAnnounce("⚠️ Crash já está ativo!", Color3.fromRGB(255, 255, 0), 3)
		return
	end

	crashing = true
	sendAnnounce("💥 Iniciando crash infinito com "..fruit, Color3.fromRGB(255, 0, 0), 3)

	crashThread = task.spawn(function()
		while crashing do
			skillz:FireServer(game.Players.LocalPlayer.Name)
			task.wait(0.01)
		end
	end)
end



local function stopCrash()
	if crashing then
		crashing = false
		sendAnnounce("🛑 Crash interrompido com sucesso.", Color3.fromRGB(0, 255, 0), 3)
	else
		sendAnnounce("⚠️ Nenhum crash ativo no momento.", Color3.fromRGB(255, 255, 0), 3)
	end
end




local function giveKen()
	local ken = plr:FindFirstChild("values") and plr.values:FindFirstChild("Ken")
	if ken then
		ken.Value = 1
	else
		print("Nao tem ken nesse lugar ai: " .. ken)
	end
end

local function noCooldown()
	local fruit = nil
	for _,v in pairs(plr.Backpack:GetChildren()) do
		for _,f in pairs(game.ReplicatedStorage.Fruits:GetChildren()) do
			if v.Name == f.Name then fruit = f.Name end
		end
	end
	if not fruit then
		for _,v in pairs(plr.Character:GetChildren()) do
			for _,f in pairs(game.ReplicatedStorage.Fruits:GetChildren()) do
				if v.Name == f.Name then fruit = f.Name end
			end
		end
	end
	local skillFolder = game.ReplicatedStorage.FruitSkills:FindFirstChild(fruit)
	local keys = {"Z", "X", "C", "V"}
	if skillFolder then
		for _,k in pairs(keys) do
			local s = skillFolder:FindFirstChild(k)
			if s and s:FindFirstChild("Cooldown") then
				s.Cooldown.Value = 0
			end
		end
	end

	for _,sword in pairs(plr.Backpack:GetChildren()) do
		local skill = game.ReplicatedStorage.SwordSkills:FindFirstChild(sword.Name)
		if skill then
			for _,k in pairs(keys) do
				local s = skill:FindFirstChild(k)
				if s and s:FindFirstChild("Cooldown") then
					s.Cooldown.Value = 0
				end
			end
		end
	end
end

local function allSwords()
	for _,v in pairs(plr.values:GetChildren()) do
		if v.Name:match("^Sword%d+") then
			v.Value = 1
		end
	end
end

local function allAccs()
	for _,v in pairs(plr.values:GetChildren()) do
		if v.Name:match("^Acc%d+") then
			v.Value = 1
		end
	end
end


-- FruitNotifier function
local function FruitNotifier()
    local sharkBoss = workspace.Islands.Island5.Bandits:FindFirstChild("Pillager [Lvl 500]")
    if not sharkBoss then return end

    for _, descendant in pairs(workspace:GetDescendants()) do
        if descendant.Name == sharkBoss.Name then
            sendAnnounce("🚨 [Event Notifier]: Um evento está ocorrendo no servidor! Evento: " .. descendant.Name, Color3.fromRGB(0, 255, 0), 2)

            local highlight = Instance.new("Highlight")
            highlight.Name = "BossHighlight"
            highlight.OutlineColor = Color3.fromRGB(255, 0, 0)
            highlight.FillColor = Color3.fromRGB(226, 0, 0)
            highlight.FillTransparency = 0.3
            highlight.OutlineTransparency = 0
            highlight.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
            highlight.Parent = descendant

            local billboard = Instance.new("BillboardGui")
            billboard.AlwaysOnTop = true
            billboard.Size = UDim2.new(0, 150, 0, 20)
            billboard.MaxDistance = math.huge
            billboard.Adornee = descendant:FindFirstChild("Head") or descendant.PrimaryPart or descendant
            billboard.Parent = descendant

            local billboard2 = Instance.new("BillboardGui")
            billboard2.AlwaysOnTop = true
            billboard2.Size = UDim2.new(0, 150, 0, 20)
            billboard2.MaxDistance = math.huge
            billboard2.Adornee = descendant:FindFirstChild("Head") or descendant.PrimaryPart or descendant
            billboard2.Parent = descendant

            local label = Instance.new("TextLabel")
            label.Size = UDim2.new(1, 0, 1, 0)
            label.Position = UDim2.new(0, 0, 0, 0)
            label.BackgroundTransparency = 1
            label.TextScaled = true
            label.TextSize = 14
            label.TextColor3 = Color3.fromRGB(255, 255, 255)
            label.TextStrokeColor3 = Color3.fromRGB(0, 0, 0)
            label.TextStrokeTransparency = 0.5
            label.Text = descendant.Name
            label.Parent = billboard

            local label2 = Instance.new("TextLabel")
            label2.Size = UDim2.new(1, 0, 1, 0)
            label2.Position = UDim2.new(0, 0, 0.5, 0)
            label2.BackgroundTransparency = 1
            label2.TextScaled = true
            label2.TextSize = 14
            label2.TextColor3 = Color3.fromRGB(0, 255, 0)
            label2.TextStrokeColor3 = Color3.fromRGB(0, 0, 0)
            label2.TextStrokeTransparency = 0.5
            label2.Text = descendant:FindFirstChild("Humanoid").Health.Value
            label2.Parent = billboard2

            break
        end
    end
end

-- Start Notifier setup
local notifierStarted = false
local function startNotifier()
    if notifierStarted then
        sendAnnounce("🚨 [Notifier]: Já está ativo!", Color3.fromRGB(255, 255, 0), 2)
        return
    end
    notifierStarted = true
    sendAnnounce("🚨 [Notifier]: Agora monitorando eventos!", Color3.fromRGB(0, 255, 0), 2)

    workspace.DescendantAdded:Connect(function(descendant)
        if descendant.Name == "Shark [Lvl 2500]" then
            FruitNotifier()
        end
    end)

    -- Also run immediately once
    FruitNotifier()
end



local function vomit()
    -- LUA GOD MODE: METRALHADORA DE FRUTAS 🍍💨
    local plr = game.Players.LocalPlayer
    local rs = game:GetService("ReplicatedStorage")
    local backpack = plr:WaitForChild("Backpack")
    local fruitFolder = rs:WaitForChild("RandomFruits")
    local character = plr.Character or plr.CharacterAdded:Wait()
    local humanoid = character:WaitForChild("Humanoid")

    -- Notificação rápida
    local function notify(txt)
        pcall(function()
            game.StarterGui:SetCore("SendNotification", {
                Title = "Lua God Turbo 🤮",
                Text = txt,
                Duration = 2
            })
        end)
    end

    -- Verifica se tool é fruta
    local function isFruit(tool)
        for _, fruit in pairs(fruitFolder:GetChildren()) do
            if tool.Name == fruit.Name then
                return true
            end
        end
        return false
    end

    -- Vomita fruta sem delay
    local function vomitaToolFAST(tool)
        humanoid:EquipTool(tool)
        tool.Parent = workspace
    end

    -- MAIN: Vômito turbooo 🧠🔥
    local function vomitaFrutasRapido()
        local count = 0
        for _, tool in pairs(backpack:GetChildren()) do
            if tool:IsA("Tool") and isFruit(tool) then
                vomitaToolFAST(tool)
                count += 1
            end
        end

        if count == 0 then
            notify("Sem frutas pra vomitar 💩")
        else
            notify("Vomitadas: " .. count .. " frutas 🤢")
        end
    end

    -- EXECUTA!
    vomitaFrutasRapido()
end






-- CMD Dictionary (AT THE BOTTOM ✅)
local commands = {
    ["blerg"] = vomit,
    ["/disconnect all"] = crash,
    ["!g Ken"] = giveKen,
    ["!g NoCooldown"] = noCooldown,
    ["!g AllSwords"] = allSwords,
    ["!g AllAccs"] = allAccs,
    ["!notifier"] = startNotifier,
}

CmdTab:Label("Use o chat novo ou caixa abaixo 👇")
CmdTab:Seperator()

-- FIXED: Textbox com string como placeholder
CmdTab:Textbox("Executar Comando", "Digite o comando aqui...", function(cmd)
	if commands[cmd] then
		pcall(commands[cmd])
	else
		DiscordLib:Notification("CMD System", "❌ Comando inválido ou não encontrado!", "Erro")
	end
end)

-- Lista de comandos
CmdTab:Label("📜 Comandos:")
CmdTab:Label("!g Ken, !g NoCooldown, !g AllSwords, !g AllAccs, /crash")


-- Novo Chat 🔥
TextChatService.OnIncomingMessage = function(msg)
	local content = msg.Text
	if commands[content] then
		pcall(commands[content])
	end
end