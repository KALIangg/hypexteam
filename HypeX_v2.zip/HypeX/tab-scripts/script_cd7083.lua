local Players = game:GetService("Players")
local player = Players.LocalPlayer

-- Aplica modificações na arma
local function configureAR(ar)
	local Configuration = ar:WaitForChild("Configuration")
	local cammo = ar:WaitForChild("CurrentAmmo")

	Configuration.AmmoCapacity.Value = math.huge
	Configuration.HitDamage.Value = math.huge
	Configuration.ShotCooldown.Value = 0
	Configuration.RecoilMax.Value = 0
	Configuration.RecoilMin.Value = 0
	Configuration.MaxSpread.Value = 0
	Configuration.TotalRecoilMax.Value = 0

	-- Loop de munição
	task.spawn(function()
		while ar.Parent do
			cammo.Value = 1e9
			task.wait(0.1)
		end
	end)
end

-- Verifica se a Tool AR foi adicionada
local function watchForAR(container)
	container.ChildAdded:Connect(function(child)
		if child.Name == "AR" and child:IsA("Tool") then
			configureAR(child)
		end
	end)
end

-- Setup quando personagem aparece
local function setupCharacter(char)
	local humanoid = char:WaitForChild("Humanoid")

	humanoid.Died:Connect(function()
		print("Você morreu")
	end)

	print("Você reviveu")

	-- Verifica se já está com a AR na mão
	local arInHand = char:FindFirstChild("AR")
	if arInHand then
		configureAR(arInHand)
	end

	-- Começa a observar Character e Backpack por futuras ARs
	watchForAR(char)
	watchForAR(player.Backpack)
end

-- Inicialização
if player.Character then
	setupCharacter(player.Character)
end

player.CharacterAdded:Connect(setupCharacter)